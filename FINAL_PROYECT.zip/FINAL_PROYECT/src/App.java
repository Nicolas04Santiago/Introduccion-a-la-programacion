public class App {
    public static void main(String[] args) throws Exception {
        //llamado al formulario
        formulario_inicio form_inicio = new formulario_inicio();
    
    }
}
